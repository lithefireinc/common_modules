 <script type="text/javascript" src="/js/ext34/examples/ux/fileuploadfield/FileUploadField.js"></script>
 <link rel="stylesheet" type="text/css" href="/js/ext34/examples/ux/fileuploadfield/css/fileuploadfield.css" />
 <script type="text/javascript">
 Ext.namespace("hrisv2_my_dtr");
 hrisv2_my_dtr.app = function()
 {
 	return{
 		init: function()
 		{
 			ExtCommon.util.init();
 			ExtCommon.util.quickTips();
                        ExtCommon.util.validations();
 			this.getGrid();
 		},
 		getGrid: function()
 		{
 			ExtCommon.util.renderSearchField('searchby');

 			var Objstore = new Ext.data.Store({
 						proxy: new Ext.data.HttpProxy({
 							url: "<?php echo site_url("admin/getDtr")?>",
 							method: "POST"
 							}),
 						reader: new Ext.data.JsonReader({
 								root: "data",
 								id: "id",
 								totalProperty: "totalCount",
 								fields: [
 											{ name: "id"},
 											{ name: "employee_id"},
 											{name: "name"},
 											{ name: "dtr_date"},
                                                                                        { name: "dtr_time"}
 										]
 						}),
 						remoteSort: true,
 						baseParams: {start: 0, limit: 25}
 					});
			var xg = Ext.grid;

 			var Grid = new Ext.grid.GridPanel({
 				id: 'hrisv2_my_dtrgrid',
 				height: 422,
 				width: '100%',
 				border: true,
 				ds: Objstore,
 				cm:  new Ext.grid.ColumnModel(
 						[						  new xg.RowNumberer(),
 												  { header: "Employee Id", dataIndex: "employee_id", width: 150, sortable: true},
 												  { header: "Employee Name", dataIndex: "name", width: 250, sortable: true},
                                                  { header: "DTR Date", dataIndex: "dtr_date", width: 150, sortable: true},
                                                  { header: "DTR Log", dataIndex: "dtr_time", width: 100, sortable: true}
 						]
 				),
 				sm: new Ext.grid.RowSelectionModel({singleSelect:true}),
 	        	loadMask: true,
 	        	bbar:
 	        		new Ext.PagingToolbar({
 		        		autoShow: true,
 				        pageSize: 25,
 				        store: Objstore,
 				        displayInfo: true,
 				        displayMsg: 'Displaying Results {0} - {1} of {2}',
 				        emptyMsg: "No Data Found."
 				    }),
 				tbar: [new Ext.form.ComboBox({
                    fieldLabel: 'Search',
                    hiddenName:'searchby-form',
                    id: 'searchby',
                    typeAhead: true,
                    triggerAction: 'all',
                    emptyText:'Search By...',
                    selectOnFocus:true,

                    store: new Ext.data.SimpleStore({
				         id:0
				        ,fields:
				            [
				             'myId',   //numeric value is the key
				             'myText' //the text value is the value

				            ]


				         , data: [['id', 'ID'], ['sd', 'Short Description'], ['ld', 'Long Description']]

			        }),
				    valueField:'myId',
				    displayField:'myText',
				    mode:'local',
                    width:100,
                    hidden: true

                }), {
					xtype:'tbtext',
					text:'Search:'
				},'   ', new Ext.app.SearchField({ store: Objstore, width:250}),
				{
                                                            xtype: 'datefield',
                                                            name: 'date_from',
                                                            id: 'date_from',
                                                            format: 'Y-m-d',
                                                            fieldLabel: 'From',
                                                            allowBlank: false,
                                                            anchor: '90%',
                                                            vtype: 'daterange',
                                                            endDateField: 'date_to',
                                                            listeners:{
                                                              change: function(){
                                                                 hrisv2_my_dtr.app.Grid.getStore().setBaseParam("date_from", this.getRawValue());          
                                                              },
                                                              blur: function(){
                                                                           
                                                                  }
                                                            }
                                                       },

                                                      {
                                                            xtype: 'datefield',
                                                            name: 'date_to',
                                                            id: 'date_to',
                                                            format: 'Y-m-d',
                                                            fieldLabel: 'To',
                                                            allowBlank: false,
                                                            anchor: '90%',
                                                            vtype: 'daterange',
                                                            startDateField: 'date_from',
                                                            listeners:{
                                                              change: function(){
                                                                   hrisv2_my_dtr.app.Grid.getStore().setBaseParam("date_to", this.getRawValue());                
                                                              },
                                                              blur: function(){
                                                                           
                                                                  }
                                                            }
                                                      }, '-', '   ',
                                                      {xtype: 'tbbutton', 
                                                      text: 'Refresh Grid', 
                                                      handler: function(){
                                                      	hrisv2_my_dtr.app.Grid.getStore().load({params:{start: 0, limit: 25}});
                                                      	}
                                                    },
                                {
 					     	xtype: 'tbfill'
 					 	},
 					 	{xtype: 'button', text: 'UPLOAD EXCEL',
                                                    icon: '<?=base_url()?>images/icons/picture_add.png',
          	 	 			        	handler: function () {
                                                                    var attform = new Ext.form.FormPanel({
											id: 'atthform',
											name: 'atthform',
											method: 'POST',
											height: 110,
											width: 342,
											labelWidth: 75,
											frame: true,
											fileUpload: true,
											items: [
												{
            xtype: 'fileuploadfield',
            id: 'file',
            emptyText: 'Select a CSV file',
            fieldLabel: 'File',
            anchor: '95%',
            name: 'file',
            allowBlank: false,
            buttonText: 'Browse'
        }
												/*{
													xtype: 'textfield',
											    	fieldLabel: 'Select file to upload',
											    	name: 'file',
											    	id: 'file',
											    	inputType: 'file',
											    	disableKeyFilter: true,
											    	anchor: '95%',
                                                    autoCreate: {tag: 'input', type: 'text', size: '200', autocomplete: 'off'}
												}*/
											]
										});

										var watth = new Ext.Window({
											title: "Upload excel",
											width: 500,
											height: 120,
											modal: true,
											plain: true,
											buttonAlign: 'right',
											bodyStyle: 'padding:5px;',
											resizable: false,
											layout: 'fit',
											items: [attform],
											buttons: [
												{
													text: "Upload",
													icon: '<?=base_url()?>images/icons/picture_save.png',
cls:'x-btn-text-icon',

													handler: function(){
														if (!attform.form.isValid()){
						        							Ext.Msg.show({
						        								title: "Error!",
						        								msg: "Please fill-in required fields (Marked Red)!",
						        								icon: Ext.Msg.ERROR,
						        								buttons: Ext.Msg.OK
						        							});
						        							return;
						        						}



						        						attform.form.submit({
						        							url: '<?php echo site_url("admin/uploadDtr"); ?>',
						        							
						        							method: 'POST',
						        							success: function(f,a){
						        								Ext.Msg.show({
						        									title: 'Success',
						        									msg: a.result.data, //"An error has occured while trying to save the record!",
						        									icon: Ext.Msg.INFO,
						        									buttons: Ext.Msg.OK
						        								});
                                                                                                                    

													            watth.close();
						        							},
						        							failure: function(f,a){
						        								Ext.Msg.show({
						        									title: 'Error Alert',
						        									msg: a.result.data, //"An error has occured while trying to save the record!",
						        									icon: Ext.Msg.ERROR,
						        									buttons: Ext.Msg.OK
						        								})
						        							},
						        							waitMsg: 'Saving data...'
						        						})
													}
												},{
													text: "Cancel",
													icon: '<?=base_url()?>images/icons/cancel.png',
                                                                                                        cls:'x-btn-text-icon',

													handler: function() {
														watth.close();
													}
												}
											]
										});
										watth.show();
          	 	  			            

                                                                }

              	 	  	                }
 	    			 ]
 	    	});

 			hrisv2_my_dtr.app.Grid = Grid;
 			hrisv2_my_dtr.app.Grid.getStore().load({params:{start: 0, limit: 25}});



var _window = new Ext.Panel({
 		        title: 'DTR',
 		        width: '100%',
 		        height:450,
 		        renderTo: 'mainBody',
 		        draggable: false,
 		        layout: 'fit',
 		        items: [hrisv2_my_dtr.app.Grid],
 		        resizable: false

 			    /*listeners : {
 				    	  close: function(p){
 					    	  window.location="../"
 					      }
 			       	} */
 	        }).render();


 		},
 		hrisv2_my_dtrSetForm: function(){
 		    var form = new Ext.form.FormPanel({
 		        labelWidth: 100,
 		        url:"<?=site_url("user/addhrisv2_my_dtr")?>",
 		        method: 'POST',
 		        defaultType: 'textfield',
 		        frame: true,

 		        items: [ {
 					xtype:'fieldset',
 					title:'hrisv2_my_dtr details',
 					width:'100%',
 					height:'auto',
 					items:[
                                           // hrisv2_my_dtr.app.employeeCombo(),
                                            {
                                                            xtype: 'datefield',
                                                            name: 'date_effective',
                                                            id: 'date_effective',
                                                            format: 'Y-m-d',
                                                            fieldLabel: 'Effective Date',
                                                            allowBlank: false,
                                                            readOnly: true,
                                                            anchor: '93%'
                                                       },
					{ xtype: 'textarea',
                                          id: 'reason',
                                          name: 'reason',
                                          anchor:'93%',
                                          fieldLabel: 'Reason',
                                          allowBlank: false,
                                          readOnly: true,
                                          maxLength: '128'
                                        }

 		        ]
 					}
 		        ]
 		    });

 		    hrisv2_my_dtr.app.Form = form;
 		},
 		hrisv2_my_dtrAdd: function(){

 			hrisv2_my_dtr.app.hrisv2_my_dtrSetForm();

 		  	var _window;

 		    _window = new Ext.Window({
 		        title: 'New hrisv2_my_dtr',
 		        width: 450,
 		        height:250,
 		        layout: 'fit',
 		        plain:true,
 		        modal: true,
 		        bodyStyle:'padding:5px;',
 		        buttonAlign:'center',
 		        items: hrisv2_my_dtr.app.Form,
 		        buttons: [{
 		         	text: 'Save',
                                icon: '<?=base_url()?>images/icons/disk.png',  cls:'x-btn-text-icon',

 	                handler: function () {
 			            if(ExtCommon.util.validateFormFields(hrisv2_my_dtr.app.Form)){//check if all forms are filled up

 		                hrisv2_my_dtr.app.Form.getForm().submit({
 			                success: function(f,action){
                 		    	Ext.MessageBox.alert('Status', action.result.data);
                  		    	 Ext.Msg.show({
  								     title: 'Status',
 								     msg: action.result.data,
  								     buttons: Ext.Msg.OK,
  								     icon: 'icon'
  								 });
 				                ExtCommon.util.refreshGrid(hrisv2_my_dtr.app.Grid.getId());
 				                _window.destroy();
 			                },
 			                failure: function(f,a){
 								Ext.Msg.show({
 									title: 'Error Alert',
 									msg: a.result.data,
 									icon: Ext.Msg.ERROR,
 									buttons: Ext.Msg.OK
 								});
 			                },
 			                waitMsg: 'Saving Data...'
 		                });
 	                }else return;
 	                }
 	            },{
 		            text: 'Cancel',
                            icon: '<?=base_url()?>images/icons/cancel.png', cls:'x-btn-text-icon',

 		            handler: function(){
 			            _window.destroy();
 		            }
 		        }]
 		    });
 		  	_window.show();
 		},
 		hrisv2_my_dtrEdit: function(){


 			if(ExtCommon.util.validateSelectionGrid(hrisv2_my_dtr.app.Grid.getId())){//check if user has selected an item in the grid
 			var sm = hrisv2_my_dtr.app.Grid.getSelectionModel();
 			var id = sm.getSelected().data.id;

 			hrisv2_my_dtr.app.hrisv2_my_dtrSetForm();
 		    _window = new Ext.Window({
 		        title: 'View hrisv2_my_dtr',
 		        width: 450,
 		        height:220,
 		        layout: 'fit',
 		        plain:true,
 		        modal: true,
 		        bodyStyle:'padding:5px;',
 		        buttonAlign:'center',
 		        items: hrisv2_my_dtr.app.Form,
 		        buttons: [/*{
 		         	text: 'Save',
                                icon: '<?=base_url()?>images/icons/disk.png',  cls:'x-btn-text-icon',

 		            handler: function () {
 			            if(ExtCommon.util.validateFormFields(hrisv2_my_dtr.app.Form)){//check if all forms are filled up
 		                hrisv2_my_dtr.app.Form.getForm().submit({
 			                url: "<?=site_url("user/updatehrisv2_my_dtr")?>",
 			                params: {id: id},
 			                method: 'POST',
 			                success: function(f,action){
                 		    	Ext.MessageBox.alert('Status', action.result.data);
 				                ExtCommon.util.refreshGrid(hrisv2_my_dtr.app.Grid.getId());
 				                _window.destroy();
 			                },
 			                failure: function(f,a){
 								Ext.Msg.show({
 									title: 'Error Alert',
 									msg: a.result.data,
 									icon: Ext.Msg.ERROR,
 									buttons: Ext.Msg.OK
 								});
 			                },
 			                waitMsg: 'Updating Data...'
 		                });
 	                }else return;
 		            }
 		        },*/{
 		            text: 'Close',
                            icon: '<?=base_url()?>images/icons/cancel.png', cls:'x-btn-text-icon',

 		            handler: function(){
 			            _window.destroy();
 		            }
 		        }]
 		    });




 		  	hrisv2_my_dtr.app.Form.getForm().load({
 				url: "<?=site_url("admin/loadhrisv2_my_dtr")?>",
 				method: 'POST',
 				params: {id: id},
 				timeout: 300000,
 				waitMsg:'Loading...',
 				success: function(form, action){


                                    _window.show();
                                    Ext.getCmp('employee_combo').setRawValue(action.result.data.employee_name);


 				},
 				failure: function(form, action) {
         					Ext.Msg.show({
 									title: 'Error Alert',
 									msg: "A connection to the server could not be established",
 									icon: Ext.Msg.ERROR,
 									buttons: Ext.Msg.OK,
 									fn: function(){ _window.destroy(); }
 								});
     			}
 			});
 			}else return;
 		},
		hrisv2_my_dtrDelete: function(){


			if(ExtCommon.util.validateSelectionGrid(hrisv2_my_dtr.app.Grid.getId())){//check if user has selected an item in the grid
			var sm = hrisv2_my_dtr.app.Grid.getSelectionModel();
			var id = sm.getSelected().data.id;
			Ext.Msg.show({
   			title:'Delete',
  			msg: 'Are you sure you want to delete this record?',
   			buttons: Ext.Msg.OKCANCEL,
   			fn: function(btn, text){
   			if (btn == 'ok'){

   			Ext.Ajax.request({
							url: "<?=site_url("user/deletehrisv2_my_dtr")?>",
							params:{ id: id},
							method: "POST",
							timeout:300000000,
			                success: function(responseObj){
                		    	var response = Ext.decode(responseObj.responseText);
						if(response.success == true)
						{
							Ext.Msg.show({
								title: 'Status',
								msg: "Record deleted successfully",
								icon: Ext.Msg.INFO,
								buttons: Ext.Msg.OK
							});
							hrisv2_my_dtr.app.Grid.getStore().load({params:{start:0, limit: 25}});

							return;

						}
						else if(response.success == false)
						{
							Ext.Msg.show({
								title: 'Error!',
								msg: "There was an error encountered in deleting the record. Please try again",
								icon: Ext.Msg.ERROR,
								buttons: Ext.Msg.OK
							});

							return;
						}
							},
			                failure: function(f,a){
								Ext.Msg.show({
									title: 'Error Alert',
									msg: "There was an error encountered in deleting the record. Please try again",
									icon: Ext.Msg.ERROR,
									buttons: Ext.Msg.OK
								});
			                },
			                waitMsg: 'Deleting Data...'
						});
   			}
   			},

   			icon: Ext.MessageBox.QUESTION
			});

	                }else return;


		},
                callLogTypeCombo: function(){

		return {
			xtype:'combo',
			id:'hrisv2_my_dtr_type',
			hiddenName: 'hrisv2_my_dtr_type_id',
                        hiddenId: 'hrisv2_my_dtr_type_id',
			name: 'hrisv2_my_dtr_type',
			valueField: 'id',
			displayField: 'name',
			//width: 100,
			anchor: '93%',
			triggerAction: 'all',
			minChars: 2,
			forceSelection: true,
			enableKeyEvents: true,
			pageSize: 10,
			resizable: true,
			readOnly: false,
			minListWidth: 300,
			allowBlank: false,
			store: new Ext.data.JsonStore({
			id: 'idsocombo',
			root: 'data',
			totalProperty: 'totalCount',
			fields:[{name: 'id'}, {name: 'name'}],
			url: "<?php echo site_url("user/callLogTypeCombo"); ?>",
			baseParams: {start: 0, limit: 10}

			}),
			listeners: {
			select: function (combo, record, index){

                        Ext.get(this.hiddenName).dom.value  = record.get('id');
			this.setRawValue(record.get('name'));
			//Ext.getCmp(this.id).setValue(record.get('name'));

			},
			blur: function(){
			var val = this.getRawValue();
			this.setRawValue.defer(1, this, [val]);
			this.validate();
			},
			render: function() {
			this.el.set({qtip: 'Type at least ' + this.minChars + ' characters to search for a school'});

			},
			keypress: {buffer: 100, fn: function() {
			Ext.get(this.hiddenName).dom.value  = '';
			if(!this.getRawValue()){
			this.doQuery('', true);
			}
			}}
			},
			fieldLabel: 'Call Log Type'

			}
	},
        employeeCombo: function(){

		return {
			xtype:'combo',
			id:'employee_combo',
			hiddenName: 'employee_id',
                        hiddenId: 'employee_id',
			name: 'employee_combo',
			valueField: 'id',
			displayField: 'name',
			//width: 100,
			anchor: '93%',
			triggerAction: 'all',
			minChars: 2,
			forceSelection: true,
			enableKeyEvents: true,
			pageSize: 10,
			resizable: true,
			readOnly: true,
			minListWidth: 300,
			allowBlank: false,
			store: new Ext.data.JsonStore({
			id: 'idsocombo',
			root: 'data',
			totalProperty: 'totalCount',
			fields:[{name: 'id'}, {name: 'name'}],
			url: "<?php echo site_url("user/employeeCombo"); ?>",
			baseParams: {start: 0, limit: 10}

			}),
			listeners: {
			select: function (combo, record, index){

                        Ext.get(this.hiddenName).dom.value  = record.get('id');
			this.setRawValue(record.get('name'));
			//Ext.getCmp(this.id).setValue(record.get('name'));

			},
			blur: function(){
			var val = this.getRawValue();
			this.setRawValue.defer(1, this, [val]);
			this.validate();
			},
			render: function() {
			this.el.set({qtip: 'Type at least ' + this.minChars + ' characters to search for a school'});

			},
			keypress: {buffer: 100, fn: function() {
			Ext.get(this.hiddenName).dom.value  = '';
			if(!this.getRawValue()){
			this.doQuery('', true);
			}
			}}
			},
			fieldLabel: 'Employee'

			}
	},
        setNoOfDays: function(){

                        var portion = Ext.getCmp("leave_portion").getValue();

                        if(portion == 'FIRST HALF' || portion == 'SECOND HALF'){
                            hrisv2_my_dtr.app.setNoOfDaysByPortion();
                            return;
                        }

			obj 	 = Ext.getCmp('no_days');
			objdate1 = Ext.getCmp("date_from").getRawValue();
			objdate2 = Ext.getCmp("date_to").getRawValue();
                        //alert(objdate1);
			if(objdate1 != "" || objdate2 != "")
			{
				ddate1 = new Date();
				ddate2 = new Date();
				diff = new Date();

				if(String(objdate1).indexOf("-") != -1)
					arDate1 = objdate1.split("-");
				else
					arDate1 = objdate1.split("/");

				if(String(objdate2).indexOf("-") != -1)
					arDate2 = objdate2.split("-");
				else
					arDate2 = objdate2.split("/");

				ddate1temp = new Date(arDate1[0], arDate1[1]-1, arDate1[2]);
				ddate1.setTime(ddate1temp.getTime());

				ddate2temp = new Date(arDate2[0], arDate2[1]-1, arDate2[2]);
				ddate2.setTime(ddate2temp.getTime());

				//sets difference date to difference of first date and second date
				diff.setTime(Math.abs(ddate1.getTime() - ddate2.getTime()));
				timediff = diff.getTime();

				weeks = Math.floor(timediff / (1000 * 60 * 60 * 24 * 7));
				timediff -= weeks * (1000 * 60 * 60 * 24 * 7);

				days = Math.floor(timediff / (1000 * 60 * 60 * 24));
				timediff -= days * (1000 * 60 * 60 * 24);

				totaldays = (weeks*7) + days;

				if(!isNaN(Number(totaldays)))
				{
					dispvalue = (ddate1.getTime() > ddate2.getTime() ? "-"+(hrisv2_my_dtr.app.round(totaldays)+1) : (hrisv2_my_dtr.app.round(totaldays)+1));
					obj.setValue((String(dispvalue).indexOf(".") == -1 ? (dispvalue)+".0" : dispvalue));
				}
				else
					obj.setValue("");
			}
			else
			{
				obj.setValue("");
			}
		},
                round: function(number,X){
			X = (!X ? 2 : X);
			return Math.round(number*Math.pow(10,X))/Math.pow(10,X);
		},
                setNoOfDaysByPortion: function(){

			if(Ext.getCmp("leave_portion").getValue() != "WHOLE DAY")
			{
				Ext.getCmp('no_days').setValue('0.5');
				Ext.getCmp("date_to").setValue(Ext.getCmp("date_from").getValue());
			}
			else
				hrisv2_my_dtr.app.setNoOfDays();
		},
                leaveFormat: function(val){

			var fmtVal;

			switch(val){
				case "1"	: 	fmtVal = '<span style="color: blue; font-weight: bold;">Yes</span>'; break;
			 	case "0"	:  	fmtVal = '<span style="color: red; font-weight: bold;">No</span>'; break;

			}

			return fmtVal;
		}//end of functions
 	}

 }();

 Ext.onReady(hrisv2_my_dtr.app.init, hrisv2_my_dtr.app);

</script>

<div id="mainBody">
</div>