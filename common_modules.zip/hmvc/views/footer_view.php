<!--<style type="text/css">



a:link {

	color: #FFF;

}

a:visited {

	color: #FFF;

}

a:hover {

	color:#FFF;

}

a:active {

	color: #FFF;

}



</style>--><div id="mainfooter">

  <div align="center">SWP v1 / COPYRIGHT &copy; 2012 Lithefire Solutions Inc.<br />

  <a href="http://www.pixelcatalyst.net">www.lithefire.net</a></div>

  

     

  </div>





  <div id="rightfooter">

    <div id="imagefooter"></div>

  </div>

    

</div>



</body>



</html>