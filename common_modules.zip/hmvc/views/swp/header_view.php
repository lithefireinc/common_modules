<html>



    <head>



        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

        <title><?php echo $title; ?></title>

		<link href= "/dev/ogs/css/ui_mainpage.css" rel="stylesheet" type="text/css" />

<!--[if lt IE 8]>







<style type="text/css">







#xouter{display:block}



#xcontainer{top:50%;display:block}



#xinner{top:-50%;position:relative}







</style>



<![endif]-->









<!--[if IE 7]>







<style type="text/css">







#xouter{



position:relative;



/*overflow:hidden;*/







}



</style>







<![endif]-->



 



        <!-- ** CSS ** -->



        <!-- base library -->



        <link rel="stylesheet" type="text/css" href="/js/ext34/resources/css/ext-all.css" />

        <!-- overrides to base library -->



<style type="text/css">

</style></head>

<body>

<!-- ** Javascript ** -->

        <!-- ExtJS library: base/adapter -->

        <script type="text/javascript" src="/js/ext34/adapter/ext/ext-base.js"></script>

        <script type="text/javascript" src="/js/commonjs/ExtCommon.js"></script>

        <!-- ExtJS library: all widgets -->

        <script type="text/javascript" src="/js/ext34/ext-all-debug.js"></script>

    













        

<div id="maincontent">

  <div id="left">

     <div id="object2"><img src="/images/ogslogo.png" /></div>

     

  </div>





  <div id="right">

    <div id="object1"><img src="/images/ogsrightheader.png" align="right" /></div>

  </div>

    

</div>
<div id="userControls">

</div>


<!--<div id="bar"></div>-->



















