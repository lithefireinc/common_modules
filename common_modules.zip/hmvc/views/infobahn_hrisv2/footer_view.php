<style type="text/css">

<!--

a:link {

	color: #000;

}

a:visited {

	color: #000;

}

a:hover {

	color: #000;

}

a:active {

	color: #000;

}


-->

</style><div id="mainfooter">

  <div align="center">HRISv2 / COPYRIGHT &copy; 2011 Lithefire Solutions Inc.<br /></div>

  <div class ="footer" align="center">www.pixelcatalyst.net</div>

  

     

  </div>





  <div id="rightfooter">

    <div id="imagefooter"></div>

  </div>

    

</div>



</body>



</html>