<div height="300" style="background-color: white">

<?php
echo "This module is currently under maintenance. Thank you for your patience.";

?>
</div>