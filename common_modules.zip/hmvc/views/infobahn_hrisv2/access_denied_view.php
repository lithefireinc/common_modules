<div height="300" style="background-color: white">
    
<?php
echo "You have no access to this module";

?>
</div>