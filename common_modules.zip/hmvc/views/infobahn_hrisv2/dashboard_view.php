<div id="mainBody"><img src="<?=base_url()?>/images/dashboard.png" width= "100%" />
</div>