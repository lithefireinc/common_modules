<html xmlns="http://www.w3.org/1999/xhtml">

   <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title><?php echo $title;?></title>

<style type="text/css">
#mainBody {width:900px; height:450px; position:absolute; top:50%; left:50%; margin:-225px auto auto -450px;}



</style>
<!--[if lt IE 8]>

<style type="text/css">

#xouter{display:block}
#xcontainer{top:50%;display:block}
#xinner{top:-50%;position:relative}

</style>
<![endif]-->
<!--[if IE 7]>

<style type="text/css">

#xouter{
position:relative;
/*overflow:hidden;*/

}
</style>

<![endif]-->

        <!-- ** CSS ** -->
        <!-- base library -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ext-all.css" />

        <!-- overrides to base library -->


       

        <!-- overrides to library -->

        <!-- extensions -->

        <!-- page specific -->
   </head>
<body>
 <!-- ** Javascript ** -->
        <!-- ExtJS library: base/adapter -->
        <script type="text/javascript" src="<?php echo base_url(); ?>js/ext/adapter/ext/ext-base.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>js/commonjs/ExtCommon.js"></script>
        <!-- ExtJS library: all widgets -->
        <script type="text/javascript" src="<?php echo base_url(); ?>js/ext/ext-all-debug.js"></script>
    