<?php


echo "HMVC VIEW";
