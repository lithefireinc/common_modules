<?php

class Hmvc extends MX_Controller{
	public function index(){
		$this->load->view("hmvc_view");
	}
}
?>
